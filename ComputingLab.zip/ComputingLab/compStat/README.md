# ComputingStatistics
This lab focuses on experimenting with the ArrayList data structure and features a brief review of basic object-oriented programming.
You will need to use the .java files in this repository. You will also need to create a new file called Loan.java 

You will be creating a Loan Class to store data for a nonprofit company called Kiva. You will then generate statistics using java. You will need to write additional methods for the ComputingStatistics.java file to do this.

The directions for this lab have been shared with you by your teacher.
